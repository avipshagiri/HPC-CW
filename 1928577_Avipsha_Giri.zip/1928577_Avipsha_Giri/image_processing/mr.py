#!/usr/bin/python3.6



import sys 
from subprocess import call

for i in range(0, 10):
  call(sys.argv[1])

